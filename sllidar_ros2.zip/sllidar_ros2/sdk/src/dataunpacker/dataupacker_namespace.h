#pragma once


#define BEGIN_DATAUNPACKER_NS()  namespace sl{ namespace internal{
#define END_DATAUNPACKER_NS()  }}