typedef struct {
  double TargetTicksPerFrame;    // Desired ticks per control frame
  long Encoder;                  // Current encoder value
  long PrevEnc;                  // Previous encoder value

  int PrevInput;                 // Previous input value
  int ITerm;                     // Integral accumulator
  long output;                   // PID output (PWM)

  // Per-motor PID gains
  int Kp;
  float Ki;
  int Kd;
  int Ko;
} SetPointInfo;

SetPointInfo leftPID, rightPID;

/**** PID Global State ****/
unsigned char moving = 0;  // Is robot currently moving?

#define MAX_PWM 255
void setPIDValue()
{
  leftPID.Kp = 10;
  leftPID.Ki = 0.033;
  leftPID.Kd = 12;
  leftPID.Ko = 50;

  // Per-motor tuning
  rightPID.Kp = 20;
  rightPID.Ki = 0.033;
  rightPID.Kd = 12;
  rightPID.Ko = 50;
}

/**** PID Reset ****/
void resetPID() {
  // LEFT
  leftPID.TargetTicksPerFrame = 0.0;
  leftPID.Encoder = readEncoder(LEFT);
  leftPID.PrevEnc = leftPID.Encoder;
  leftPID.PrevInput = 0;
  leftPID.ITerm = 0;
  leftPID.output = 0;



  // RIGHT
  rightPID.TargetTicksPerFrame = 0.0;
  rightPID.Encoder = readEncoder(RIGHT);
  rightPID.PrevEnc = rightPID.Encoder;
  rightPID.PrevInput = 0;
  rightPID.ITerm = 0;
  rightPID.output = 0;


}

/**** Core PID Logic ****/
void doPID(SetPointInfo *p) {
  int input = p->Encoder - p->PrevEnc;
  int Perror = p->TargetTicksPerFrame - input;

  // PID formula using previous input (to reduce derivative kick)
  long output = (p->Kp * Perror - p->Kd * (input - p->PrevInput) + p->ITerm) / p->Ko;

  // Accumulate and constrain output
  output += p->output;

  if (output > MAX_PWM) {
    output = MAX_PWM;
  } else if (output < -MAX_PWM) {
    output = -MAX_PWM;
  } else {
    p->ITerm += p->Ki * Perror;
  }

  p->output = output;
  p->PrevEnc = p->Encoder;
  p->PrevInput = input;
}

/**** Periodic PID Update ****/
void updatePID() {
  // Read encoder values
  leftPID.Encoder = readEncoder(LEFT);
  rightPID.Encoder = readEncoder(RIGHT);

  if (!moving) {
    if (leftPID.PrevInput != 0 || rightPID.PrevInput != 0)
      resetPID();
    return;
  }

  doPID(&leftPID);
  doPID(&rightPID);

  setMotorSpeeds(leftPID.output, rightPID.output);
}
