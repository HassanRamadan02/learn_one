#ifndef CONFIG_H_
#define CONFIG_H_

#define USE_BASE 

#define USE_GENERIC_MOTOR_DRIVER   // Motor drivers with 1 Direction Pin(INA) and 1 PWM(ENABLE) pin.

//#define INDIVIDUAL_PID_GAINS     // Use specific PID coefficients for each motor
#define IDENTICAL_PID_GAINS     // Use identical PID coefficients for each motor

/* Serial port baud rate */
#define BAUDRATE 115200
#define PID_RATE 30 // Hz
#define MAX_PWM 255


/* PID Parameters */
#ifdef INDIVIDUAL_PID_GAINS    
    #define KP_RIGHT 20
    #define KD_RIGHT 12
    #define KI_RIGHT 0
    #define KO_RIGHT 30

    #define KP_LEFT 18
    #define KD_LEFT 12
    #define KI_LEFT 0
    #define KO_LEFT 30
#endif

#ifdef IDENTICAL_PID_GAINS  
    #define KP 2.25
    #define KD 1.25
    #define KI 0
    #define KO 30
#endif


/* Encoder Interrupts */
#define encoder0PinA 23      // encoder b Left
#define encoder0PinB 22       // encoder a left

#define encoder1PinA 19     // encoder b right
#define encoder1PinB 18     // encoder a right


/* Motor Driver Interrupts */
#ifdef USE_GENERIC_MOTOR_DRIVER
    #define RIGHT_MOTOR_PWM 25
    #define RIGHT_MOTOR_DIR1 32
    #define RIGHT_MOTOR_DIR2 33

    #define LEFT_MOTOR_PWM 14
    #define LEFT_MOTOR_DIR1 26
    #define LEFT_MOTOR_DIR2 27
#endif

#endif
